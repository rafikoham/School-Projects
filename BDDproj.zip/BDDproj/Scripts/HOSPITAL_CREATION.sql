ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MM-RRRR' ;


/* creating tables */

/* create a table of staff ( better have a table of doctors and patiens alone ) and rooms , patients , médicaments ,services*/


DROP TABLE STAFF CASCADE CONSTRAINTS;

CREATE TABLE STAFF(
    NOM         VARCHAR(25)         NOT NULL,
    PRENOM      VARCHAR(25)         NOT NULL,
    INSEE       NUMBER(10),
    SEXE        CHAR(1)         CHECK (SEXE IN ('M', 'F')),
    TELEPHONE   NUMBER(15)          UNIQUE,
    ADRESSE     VARCHAR(300)         NOT NULL,
    TRAV       CHAR(10)        CHECK(TRAV IN('DOCTOR','NURSE','PATIENT')),

    PRIMARY KEY(INSEE)      
);


DROP TABLE DIRECTEUR CASCADE CONSTRAINTS;
CREATE TABLE DIRECTEUR (
    NOM         VARCHAR(25)         NOT NULL,
    PRENOM      VARCHAR(25)         NOT NULL,
    INSEE       NUMBER(10),
    SEXE        CHAR(1)         CHECK (SEXE IN ('M', 'F')),
    ENTREE      DATE,                       /* le jour ou il est devnu directeur*/
    SORTIE      DATE,
    TELEPHONE   NUMBER(12)          UNIQUE,
    ADRESSE     VARCHAR(300)         NOT NULL,

    PRIMARY KEY(INSEE)      

);


DROP TABLE HosSERV CASCADE CONSTRAINTS;


CREATE TABLE HosSERV(

    SERIVCECODE        NUMBER(10)      NOT NULL,
    SERVICETEL         NUMBER(15)      NOT NULL,
    SERVICENAME        VARCHAR(100),  

             

    PRIMARY KEY(SERIVCECODE)
   
  
);



DROP TABLE ROOMS CASCADE CONSTRAINTS;
CREATE TABLE ROOMS(
    ROOMCODE        VARCHAR(10) NOT NULL,
    ROOMVOLUME      NUMBER(10),
    ROOMOCCUPANCY   NUMBER(10),

    PRIMARY KEY(ROOMCODE)
);

/* a patient that might be in this case a nurse or a doctor and even a director might occupy a room during his admission */
DROP TABLE OCCUPY CASCADE CONSTRAINTS;
CREATE TABLE OCCUPY(

    INSEE       NUMBER(10) NOT NULL,
    ROOMCODE    VARCHAR(10) NOT NULL,
    PATHOCODE   NUMBER(10) NOT NULL,
    ARRIVAL     DATE,
    DEPARTURE   DATE,

    PRIMARY KEY(INSEE,ROOMCODE),
    
    FOREIGN KEY(INSEE)      REFERENCES STAFF(INSEE),
    FOREIGN KEY(ROOMCODE)   REFERENCES ROOMS(ROOMCODE),
    FOREIGN KEY(PATHOCODE)   REFERENCES PATHOLOGY(PATHOCODE)

);

/* a service is composed of rooms distinguished by their code number*/
DROP TABLE COMPOSED CASCADE CONSTRAINTS;
CREATE TABLE COMPOSED(
    SERIVCECODE        NUMBER(10)      NOT NULL,
    ROOMCODE           VARCHAR(10)      NOT NULL,

    PRIMARY KEY(SERIVCECODE,ROOMCODE),

    FOREIGN KEY(SERIVCECODE) REFERENCES HosSERV(SERIVCECODE),
    FOREIGN KEY(ROOMCODE)    REFERENCES ROOMS(ROOMCODE)
);


/* tables for the single direct superior to whom they can refer*/
DROP TABLE SUPREFEER CASCADE CONSTRAINTS;
CREATE TABLE SUPREFEER(
    SupInsee        NUMBER(10) NOT NULL,
    INSEE           NUMBER(10) NOT NULL,

    PRIMARY KEY(SupInsee,INSEE),

    FOREIGN KEY(INSEE) REFERENCES STAFF(INSEE)
    
);


DROP TABLE PATHOLOGY CASCADE CONSTRAINTS;
CREATE TABLE PATHOLOGY(
    PATHOCODE           NUMBER(10) NOT NULL,
    PATHNAME            VARCHAR(50),
    SERIVCECODE         NUMBER(10) NOT NULL,

    PRIMARY KEY(PATHOCODE),
    FOREIGN KEY (SERIVCECODE) REFERENCES HosSERV(SERIVCECODE)

);



/*  REGISTERED in a certan service  meant only ofr nursed and  doctors , pour les patiens , j'ai mis occcupy(aussi valable pour nurses and otherrs) */
DROP TABLE REGISTERED CASCADE CONSTRAINTS;
CREATE TABLE REGISTERED(
    INSEE       NUMBER(10)   NOT NULL,
    SERIVCECODE   NUMBER(10) NOT NULL,
 


    PRIMARY KEY(INSEE,SERIVCECODE),

    FOREIGN KEY(INSEE)  REFERENCES STAFF(INSEE),
    FOREIGN KEY(SERIVCECODE) REFERENCES HosSERV(SERIVCECODE)

);

DROP TABLE TREATMENTS CASCADE CONSTRAINTS;
CREATE TABLE TREATMENTS(
    TNAME               VARCHAR(20),
    TCODE               NUMBER(10) NOT NULL,

    PRIMARY KEY(TCODE)

    
);


/* a table that links a pathology to a treatment , in fact one pathology can have multiple treatment */

DROP TABLE CURED_BY CASCADE CONSTRAINTS;

CREATE TABLE CURED_BY(
     PATHOCODE      NUMBER(10) NOT NULL,
     TCODE          number(10) NOT NULL,

     PRIMARY KEY(PATHOCODE,TCODE),

     FOREIGN KEY(PATHOCODE) REFERENCES PATHOLOGY(PATHOCODE),
     FOREIGN KEY(TCODE)     REFERENCES TREATMENTS(TCODE)


);


/* creating a table for the " performance" of a doctor/nurse on a patient in a certain room , "performing a procedure"*/

DROP TABLE PERFORMS CASCADE CONSTRAINTS;

CREATE TABLE PERFORMS(

    DocINSEE           NUMBER(10)   NOT NULL,
    PatInsee           NUMBER(10)   NOT NULL,
    ROOMCODE           VARCHAR(10)  NOT NULL,


    PRIMARY KEY(DocINSEE,PatInsee),
    FOREIGN KEY(ROOMCODE) REFERENCES ROOMS(ROOMCODE)

);


DROP TABLE PROCEDURE CASCADE CONSTRAINTS;

CREATE TABLE PROCEDURE(

    PID         VARCHAR(10) NOT NULL,
    PNAME       VARCHAR(40) NOT NULL,
    INSEE      NUMBER(10)  NOT NULL,
    DateProc    DATE,
    TCODE       number(10)  NOT NULL,
    COST        NUMBER(10),
    RESULT      VARCHAR(15)  CHECK(RESULT IN ('POSITIVE','NEGATIVE')),


    PRIMARY KEY(PID,TCODE),
    FOREIGN KEY(INSEE) REFERENCES STAFF(INSEE),
    FOREIGN KEY(TCODE) REFERENCES TREATMENTS(TCODE)

);




COMMIT;