ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MM-RRRR' ;

/* inserting in the Staff table*/


/* mettre des patients d'abord ici*/
insert into STAFF values('Passy','Antoine',118122,'M',0649567841,'04 Rue de la pompe Paris 75016','PATIENT');
insert into STAFF values('Russy','Marion',118123,'F',0649567831,'06 Avenue de la garde 75013 Paris ','PATIENT');
insert into STAFF values('Salim','Desnoix',118124,'M',0649537841,'11 Allée de beauté 94052 Nogent sur marne','PATIENT');
insert into STAFF values('Sara','frobenius',118112,'F',0649567822,'128 Rue saint maurice,94150 Rungis','PATIENT');
insert into STAFF values('Maelle','Fontenay',123122,'F',071567841,'3 Rue Jean Paul Sartre 77186 Noisiel','PATIENT');
insert into STAFF values('Amine','Lagrange',32122,'M',0729567841,'01 bis avenue du maine 75015 Paris','PATIENT');
insert into STAFF values('Doumbia','Massy',21122,'M',0645784100,'34 Rue du bac Paris','PATIENT');
insert into STAFF values('Aline','Mandoline',458122,'F',0710567841,'66 impasse des cygnes Isle-Adam','PATIENT');
insert into STAFF values('Fatiya','Nebul',654112,'F',0989567841,'6 Rue Bérault Vincenne','PATIENT');

/* insertion des nurses */

insert into STAFF values('Dechacal','Vincent',7712345,'M',0912345676,'05 rue des glycines Vincenne','NURSE');
insert into STAFF values('Vaucluse','Lara',78123,'F',06495641,'98 allée des bois champs sur marne','NURSE');
insert into STAFF values('Haim','Anissa',4529,'F',0213567841,'02 avenue de la malnoue Noisy le grand','NURSE');
insert into STAFF values('Verouille','Sarah',4074,'F',0966668885,'14 rue du chateau bry sur marne','NURSE');
insert into STAFF values('Delort','Francine',1267,'F',0633333331,'76 rue jean jaurès neuilly sur seine','NURSE');
insert into STAFF values('Ramanès','Rafik',9986,'M',0988888887,'09 BIS rue de puteaux Suresne','NURSE');
insert into STAFF values('Calibry','Daniel',870999,'M',0111113455,'75 impasse des loups Marne la coquette','NURSE');
insert into STAFF values('Cohen','Danaele',12209,'F',0555544893,'41 rue de la manufacture Saint cloud','NURSE');
insert into STAFF values('Francoville','Said',449093,'M',0113339000,'20 rue des monuments clamart','NURSE');
insert into STAFF values('Ben Hammou','Haroune',2894437,'M',0989234551,'99 avenue Alger  Antony','NURSE');



/* insertion des Doctors */

insert into STAFF values('Batuhan','Koç', 99012,'M',0774903112,'22 Avenue Rouget Cesson','DOCTOR');
insert into STAFF values('Drogne','Stella',990123,'F',0989875655,'45 Rue de londre 75008 PARIS','DOCTOR');
insert into STAFF values('Passy','Melissa',991234,'F',1123456900,'21 rue de la manufacture saint cloud','DOCTOR');
insert into STAFF values('Franco','Antonio',99845,'M',0699967841,'555 Grand Avenue de france Boulogne sur Mer','DOCTOR');
insert into STAFF values('Abdul','Bari',4566609,'M',09876543222,'12 Impasse Drogne Villfresne','DOCTOR');
insert into STAFF values('Matellis','Calypso',2828282,'F',0331234567,'08 rue Victor Hugo Alger 16000' ,'DOCTOR');
insert into STAFF values('Hamid','Hakimi',18956,'M',0981111111,'09 Bank avenue Sheffeild ','DOCTOR');
insert into STAFF values('Franco','Cecilia',54609,'F',0222214551,'76 via Luigi Vanvitteli Napoli','DOCTOR');


/* Insertion unique du directeur  qui sera moi , no offense*/

insert into DIRECTEUR values('Hammoutène','Rafik',999099990,'M','02-01-2021','',0749021128,'Rue des héros nogentais nogent sur marne 94052');


/* Insertion dans la table HosServ , les services de l'Hoptial*/

insert into HosServ values(10,11248,'endocrinolgie');
insert into HosServ values(11,11258,'cardiology');
insert into HosServ values(12,11268,'pediatrics');
insert into HosServ values(13,11278,' oncology');
insert into HosServ values(14,11288,'neurolgy');
insert into HosServ values(15,11298,'urology');
insert into HosServ values(16,11300,'Nephrology');



/* insert des valuers for the table rooms*/

insert into ROOMS values('E1',15,2);
insert into ROOMS values('E2',23,10);
insert into ROOMS values('E3',45,24);
insert into ROOMS values('E4',46,21);
insert into ROOMS values('E5',12,7);
insert into ROOMS values('C1',12,5);
insert into ROOMS values('C2',8,2);
insert into ROOMS values('C3',67,63);
insert into ROOMS values('C4',55,40);
insert into ROOMS values('C5',34,24);
insert into ROOMS values('C6',4,1);
insert into ROOMS values('T1',12,10);
insert into ROOMS values('T2',11,6);
insert into ROOMS values('N1',9,4);
insert into ROOMS values('N2',15,3);
insert into ROOMS values('N3',23,7);
insert into ROOMS values('N4',21,6);
insert into ROOMS values('N5',27,20);
insert into ROOMS values('U1',56,24);
insert into ROOMS values('U2',43,29);
insert into ROOMS values('U3',20,20);
insert into ROOMS values('M1',20,2);
insert into ROOMS values('M2',34,22);
insert into ROOMS values('M3',12,3);
insert into ROOMS values('M4',74,61);
insert into ROOMS values('P1',44,31);
insert into ROOMS values('P2',51,13);
insert into ROOMS values('P3',34,18);
insert into ROOMS values('P4',25,20);
insert into ROOMS values('P5',18,3);



/* INsert intio composed , champsauqe servive a un des rooms */

/*endocrinolgie*/
insert into COMPOSED values(10,'E1');
insert into COMPOSED values(10,'E2');
insert into COMPOSED values(10,'E3');
insert into COMPOSED values(10,'E4');
insert into COMPOSED values(10,'E5');


/*cardiolgy*/
insert into COMPOSED values(11,'C1');
insert into COMPOSED values(11,'C2');
insert into COMPOSED values(11,'C3');
insert into COMPOSED values(11,'C4');
insert into COMPOSED values(11,'C5');
insert into COMPOSED values(11,'C6');

/*pediatrics*/
insert into COMPOSED values(12,'P1');
insert into COMPOSED values(12,'P2');
insert into COMPOSED values(12,'P3');
insert into COMPOSED values(12,'P4');
insert into COMPOSED values(12,'P5');

/*oncology*/

insert into COMPOSED values(13,'T1');
insert into COMPOSED values(13,'T2');

/*neurolgy*/

insert into COMPOSED values(14,'N1');
insert into COMPOSED values(14,'N2');
insert into COMPOSED values(14,'N3');
insert into COMPOSED values(14,'N4');
insert into COMPOSED values(14,'N5');

/*urology*/

insert into COMPOSED values(15,'U1');
insert into COMPOSED values(15,'U2');
insert into COMPOSED values(15,'U3');


/* Nephrology*/
insert into COMPOSED values(16,'M1');
insert into COMPOSED values(16,'M2');
insert into COMPOSED values(16,'M3');
insert into COMPOSED values(16,'M4');


/*********************Registered***********************/
/* assosiating nurse or doctor onto a serivce*/

/*FOR DOCTORS*/
insert into REGISTERED values(99012,10);
insert into REGISTERED values(990123,10);
insert into REGISTERED values(991234,11);
insert into REGISTERED values(99845,12);
insert into REGISTERED values(4566609,13);
insert into REGISTERED values(2828282,14);
insert into REGISTERED values(18956,15);
insert into REGISTERED values(54609,16);

/*for nurses*/
insert into REGISTERED values(2894437,11);
insert into REGISTERED values(449093,11);
insert into REGISTERED values(12209,12);
insert into REGISTERED values(870999,12);
insert into REGISTERED values(9986,13);
insert into REGISTERED values(1267,13);
insert into REGISTERED values(4074,14);
insert into REGISTERED values(78123,15);
insert into REGISTERED values(4529,10);
insert into REGISTERED values(7712345,16);


/* SUPREFEREEEEEEEEEEEEEEEE*/

/* all the staff refeers to the director (To me)*/ 

insert into SUPREFEER values(999099990,7712345);
insert into SUPREFEER values(999099990,4529);
insert into SUPREFEER values(999099990,78123);
insert into SUPREFEER values(999099990,4074);
insert into SUPREFEER values(999099990,1267);
insert into SUPREFEER values(999099990,9986);
insert into SUPREFEER values(999099990,870999);
insert into SUPREFEER values(999099990,12209);
insert into SUPREFEER values(999099990,449093);
insert into SUPREFEER values(999099990,2894437);
insert into SUPREFEER values(999099990,54609);
insert into SUPREFEER values(999099990,18956);
insert into SUPREFEER values(999099990,2828282);
insert into SUPREFEER values(999099990,4566609);
insert into SUPREFEER values(999099990,99845);
insert into SUPREFEER values(999099990,991234);
insert into SUPREFEER values(999099990,990123);
insert into SUPREFEER values(999099990,99012);

/*Some nurses that reffeers to doctors */
insert into SUPREFEER values(991234,2894437);
insert into SUPREFEER values(991234,449093);
insert into SUPREFEER values(99845,12209);
insert into SUPREFEER values(99845,870999);
insert into SUPREFEER values(4566609,1267);
insert into SUPREFEER values(2828282,4074);
insert into SUPREFEER values(18956,78123);
insert into SUPREFEER values(990123,4529);
insert into SUPREFEER values(54609,7712345);
insert into SUPREFEER values(4566609,9986);


/* Occupying  a room on a certain date of arrival and the departure of the room thereofre the dparture from its serivce
Every one can occupy a room*/

insert into OCCUPY values(118122,'E1',112,'12-01-2010','14-02-2010');
insert into OCCUPY values(118123,'E2',112,'04-06-2011','06-06-2011');
insert into OCCUPY values(118124,'C4',116,'16-12-2011','10-01-2012');
insert into OCCUPY values(118112,'C6',118,'22-08-2014','28-08-2014');
insert into OCCUPY values(123122,'C2',115,'30-09-2015','05-10-2015');
insert into OCCUPY values(32122,'T2',131,'11-05-2018','16-08-2018');
insert into OCCUPY values(21122,'U1',124,'06-09-2018','07-09-2018');
insert into OCCUPY values(458122,'N5',125,'10-03-2019','27-03-2019');
insert into OCCUPY values(654112,'M3',130,'10-03-2019','07-09-2019');



/***************************** insert into patholgies ******************************************/

/* for endocrinolgie*/
insert into PATHOLOGY values(110,'Hyperthyroidie',10);
insert into PATHOLOGY values(111,'hyperprolactinemie',10);
insert into PATHOLOGY values(112,'Diabète',10);
insert into PATHOLOGY values(113,'hypopituitarisme',10);
insert into PATHOLOGY values(114,'acromégalie',10);

/*for cardiolgy*/
insert into PATHOLOGY values(115,'angor',11);
insert into PATHOLOGY values(116,'angine thoraciale',11);
insert into PATHOLOGY values(117,'avc',11);
insert into PATHOLOGY values(118,'embolie pulmonaire',11);

/*for pediatrics*/
insert into PATHOLOGY values(119,'anemia',12);
insert into PATHOLOGY values(120,'asthma',12);
insert into PATHOLOGY values(121,'lukemia',12);

/*for urology*/
insert into PATHOLOGY values(122,'hermaturia',15);
insert into PATHOLOGY values(123,'prostatic hyperplasia',15);
insert into PATHOLOGY values(124,'Kidney Stones',15);

/*for neurolgy*/
insert into PATHOLOGY values(125,'ataxia',14);
insert into PATHOLOGY values(126,'tumeur hypophysaire',14);
insert into PATHOLOGY values(127,'epilepsy',14);

/*for Nephrology*/
insert into PATHOLOGY values(128,'albuminurie',16);
insert into PATHOLOGY values(129,'glomérulonéphrites',16);
insert into PATHOLOGY values(130,'polykystose',16);

/*oncology*/
insert into PATHOLOGY values(131,'Cancer de sein',13);
insert into PATHOLOGY values(132,'cancer de peau',13);

/******************************TREATMENTS*******************************/

/*treatment for Hyperthyroidie*/
insert into TREATMENTS values('thyroxine',1000);
insert into TREATMENTS values('thyronine',1001);
insert into TREATMENTS values('Levothyrox',1002);

/*treamtent for hyperprolactinemie*/
insert into TREATMENTS values('bromocriptine',1003);
insert into TREATMENTS values('cabergoline',1004);

/*treamtent for diabete*/
insert into TREATMENTS values('insuline',1005);
insert into TREATMENTS values('Biguanide',1006);

/* treatment for hypopituitarisme*/

insert into TREATMENTS values('drogue',1008);

/* treatment for acromégalie and hypopituitarisme*/
insert into TREATMENTS values('radio hypophysaire',1009);

/*treamtment for angor AND AGNICE THORACIALE*/
insert into TREATMENTS values('ibuprofène',1010);


/*treamtment for avc*/
insert into TREATMENTS values('diovan 160',1011);
insert into TREATMENTS values('diovan 8',1027);

/*treamtment for embolie pulmonaire*/
insert into TREATMENTS values('Rivaroxoban',1012);



/*treamtment for anemia*/
insert into TREATMENTS values('timoferol',1013);

/*treamtment for asthma*/
insert into TREATMENTS values('singulair',1014);

/*treamtment for lukemia*/
insert into TREATMENTS values('venclexta',1015);


/*treamtment for hermaturia*/
insert into TREATMENTS values('roayl canin detector',1016);

/*treamtment for prostatic hyperplasia*/
insert into TREATMENTS values('prostaphyl',1017);

/*treamtment for kidney stones*/
insert into TREATMENTS values('Deestone',1018);
insert into TREATMENTS values('Cystone',1028);

/*treamtment for ataxia*/
insert into TREATMENTS values('Tinnitus',1019);

/*treamtment for tumeur hypophysaire*/
insert into TREATMENTS values('adenoma',1020);

/*treamtment for epilepsy*/
insert into TREATMENTS values('epidiolex',1021);



/*treamtment for albuminurie*/
insert into TREATMENTS values('vialbex',1022);

/*treamtment for glomérulonéphrites*/
insert into TREATMENTS values('encard 2,5 mg',1023);

/*treamtment for polykystose*/
insert into TREATMENTS values('nephrokyste',1024);


/*treamtment for cancer de sein*/
insert into TREATMENTS values('docetaxel',1025);

/*treamtment for cancer de peau*/
insert into TREATMENTS values('heberferon',1026);



/***********************************************CURED BY associate every pathology to its medecine or treramtent*/
/*Hyperthyroidie*/
insert into CURED_BY values(110,1000);
insert into CURED_BY values(110,1001);
insert into CURED_BY values(110,1002);


/*treamtent for hyperprolactinemie*/
insert into CURED_BY values(111,1003);
insert into CURED_BY values(111,1004);

/*treamtent for diabete*/
insert into CURED_BY values(112,1005);
insert into CURED_BY values(112,1006);

/* treatment for hypopituitarisme*/
insert into CURED_BY values(113,1009);
insert into CURED_BY values(113,1008);

/* treatment for acromégalie*/
insert into CURED_BY values(114,1009);

/*treamtment for angor*/
insert into CURED_BY values(115,1010);

/*treamtment for angine thoraciale*/
insert into CURED_BY values(116,1010);

/*treamtment for avc*/
insert into CURED_BY values(117,1011);
insert into CURED_BY values(117,1027);

/*treamtment for embolie pulmonaire*/
insert into CURED_BY values(118,1012);



/*treamtment for anemia*/
insert into CURED_BY values(119,1013);

/*treamtment for asthma*/
insert into CURED_BY values(120,1014);

/*treamtment for lukemia*/
insert into CURED_BY values(121,1015);


/*treamtment for hermaturia*/
insert into CURED_BY values(122,1016);

/*treamtment for prostatic hyperplasia*/
insert into CURED_BY values(123,1017);

/*treamtment for kidney stones*/
insert into CURED_BY values(124,1018);
insert into CURED_BY values(124,1028);

/*treamtment for ataxia*/
insert into CURED_BY values(125,1019);

/*treamtment for tumeur hypophysaire*/
insert into CURED_BY values(126,1020);

/*treamtment for epilepsy*/
insert into CURED_BY values(127,1021);



/*treamtment for albuminurie*/
insert into CURED_BY values(128,1022);

/*treamtment for glomérulonéphrites*/
insert into CURED_BY values(129,1023);

/*treamtment for polykystose*/
insert into CURED_BY values(130,1024);


/*treamtment for cancer de sein*/
insert into CURED_BY values(131,1025);

/*treamtment for cancer de peau*/
insert into CURED_BY values(132,1026);


/************************************************PERFORMS***********************/

insert into PERFORMS values(99012,118122,'E1');
insert into PERFORMS values(99012,118123,'E1');
insert into PERFORMS values(990123,118123,'E2');
insert into PERFORMS values(991234,118124,'P1');
insert into PERFORMS values(99845,118112,'U1');
insert into PERFORMS values(4566609,123122,'C2');
insert into PERFORMS values(2828282,32122,'T1');
insert into PERFORMS values(18956,21122,'N1');
insert into PERFORMS values(54609,458122,'M1');
 

/******************procedure******************/

insert into PROCEDURE values('P1','Thyroide chirurgie via thorax',99012,'13-01-2010',1000,319,'POSITIVE');
insert into PROCEDURE values('P2','Chirurgie bariatrique',990123,'05-06-2011',1005,1540,'NEGATIVE');
insert into PROCEDURE values('P3','Chimiothérapie',991234,'03-01-2012',1015,1329,'NEGATIVE');
insert into PROCEDURE values('P4','Kidney transplant',99845,'24-08-2014',1028,871.99,'POSITIVE');
insert into PROCEDURE values('P5','chirurgie thoraciale',4566609,'01-10-2015',1010,489,'POSITIVE');
insert into PROCEDURE values('P6','Dermy',2828282,'20-06-2018',1026,329.45,'POSITIVE');
insert into PROCEDURE values('P7','Chirurgie cervical ataxique',18956,'30-09-2018',1019,1200.99,'POSITIVE');
insert into PROCEDURE values('P8','Chirurgie hydatique',54609,'13-06-2019',1024,128,'NEGATIVE');







